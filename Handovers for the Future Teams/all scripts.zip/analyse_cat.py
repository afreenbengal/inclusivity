import csv,json,math,collections,sys
import numpy as np
from scipy import stats
rows=list(csv.DictReader(open('data_raw.csv')))
for x in rows:
    for k in ('male','female','total','within_state','outside_state','econ_backward','soc_challenged_sc_st_obc','nirf_year'): x[k]=int(x[k])
    x['s']=x['soc_challenged_sc_st_obc']
INST=['berhampur','bhopal','kolkata','mohali','pune','tirupati','tvm','iisc']
NAME=dict(berhampur='Berhampur',bhopal='Bhopal',kolkata='Kolkata',mohali='Mohali',pune='Pune',tirupati='Tirupati',tvm='Thiruvananthapuram',iisc='IISc')
REF=0.495
def wilson(k,n,z=1.96):
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return c-h,c+h
S=collections.defaultdict(lambda:dict(t=0,s=0,e=0,w=0,m=0))
for x in rows:
    k=(x['institute'],x['nirf_year'])
    S[k]['t']+=x['total'];S[k]['s']+=x['s'];S[k]['e']+=x['econ_backward'];S[k]['w']+=x['within_state']
    S[k]['dy']=x['data_year']
out={'series':{},'latest':{}}
for i in INST:
    ys=sorted(y for (ii,y) in S if ii==i)
    out['series'][i]=[dict(nirf=y,data=S[(i,y)]['dy'],t=S[(i,y)]['t'],s=S[(i,y)]['s'],share=S[(i,y)]['s']/S[(i,y)]['t'],econ=S[(i,y)]['e']/S[(i,y)]['t'],within=S[(i,y)]['w']/S[(i,y)]['t']) for y in ys]
    y=ys[-1];d=S[(i,y)];lo,hi=wilson(d['s'],d['t'])
    out['latest'][i]=dict(nirf=y,data=d['dy'],t=d['t'],s=d['s'],share=d['s']/d['t'],lo=lo,hi=hi,gap_people=REF*d['t']-d['s'],within=d['w']/d['t'])
# pooled seven IISERs latest
II=[i for i in INST if i!='iisc']
T=sum(out['latest'][i]['t'] for i in II);Sx=sum(out['latest'][i]['s'] for i in II)
out['pooled']=dict(t=T,s=Sx,share=Sx/T,ci=wilson(Sx,T),gap=REF*T-Sx)
# binomial vs ref pooled (design effect ignored; descriptive)
out['pooled']['p_binom']=stats.binomtest(Sx,T,REF).pvalue
# heterogeneity chi2 across 7 IISERs latest
tab=np.array([[out['latest'][i]['s'],out['latest'][i]['t']-out['latest'][i]['s']] for i in II])
chi,p,dof,_=stats.chi2_contingency(tab);out['hetero']=dict(chi=chi,p=p,dof=dof)
tab2=np.array([[out['latest'][i]['s'],out['latest'][i]['t']-out['latest'][i]['s']] for i in INST])
c2,p2,d2,_=stats.chi2_contingency(tab2);out['hetero_all']=dict(chi=c2,p=p2,dof=d2)
# each inst vs ref
out['vs_ref']={i:stats.binomtest(out['latest'][i]['s'],out['latest'][i]['t'],REF).pvalue for i in INST}
# trends: per institute slope on data start year
def yr(dy): return int(dy[:4])
out['trend']={}
for i in INST:
    s=out['series'][i]
    if len(s)<4: continue
    X=np.array([yr(a['data']) for a in s]);Y=np.array([a['share']*100 for a in s])
    r=stats.linregress(X,Y);ci=stats.t.ppf(.975,len(X)-2)*r.stderr
    out['trend'][i]=dict(slope=r.slope,lo=r.slope-ci,hi=r.slope+ci,p=r.pvalue,n=len(X))
# panel with institute fixed effects
Xs=[];Ys=[]
for i in INST:
    s=out['series'][i]
    if len(s)<4: continue
    X=np.array([yr(a['data']) for a in s],float);Y=np.array([a['share']*100 for a in s])
    Xs+=list(X-X.mean());Ys+=list(Y-Y.mean())
r=stats.linregress(Xs,Ys);out['panel_slope']=dict(slope=r.slope,p=r.pvalue,n=len(Xs))
# yoy jumps
out['jumps']=[]
for i in INST:
    s=out['series'][i]
    for a,b in zip(s,s[1:]):
        if b['nirf']-a['nirf']==1:
            out['jumps'].append(dict(i=i,frm=a['nirf'],to=b['nirf'],d=(b['share']-a['share'])*100,dt=b['t']-a['t']))
big=[j for j in out['jumps'] if abs(j['d'])>3]
out['big_jumps']=big
# programme: latest year UG vs PG, IISERs only
ug=[0,0];pg=[0,0]
byprog=collections.defaultdict(lambda:[0,0])
for x in rows:
    if x['institute'] in II and x['nirf_year']==out['latest'][x['institute']]['nirf']:
        k='UG' if x['programme'].startswith('UG') else 'PG'
        a=ug if k=='UG' else pg
        a[0]+=x['s'];a[1]+=x['total']
        byprog[(x['institute'],x['programme'])]=[x['s'],x['total']]
out['prog']=dict(ug=ug,pg=pg,ug_share=ug[0]/ug[1],pg_share=pg[0]/pg[1])
tab=[[ug[0],ug[1]-ug[0]],[pg[0],pg[1]-pg[0]]]
out['prog']['p']=stats.fisher_exact(tab)[1];out['prog']['ci_ug']=wilson(*ug);out['prog']['ci_pg']=wilson(*pg)
# PG split by institute
pgi={}
for (i,p),(s,t) in byprog.items():
    if p.startswith('PG'): 
        a=pgi.setdefault(i,[0,0]);a[0]+=s;a[1]+=t
out['pg_by_inst']=pgi
ugi={}
for (i,p),(s,t) in byprog.items():
    if p.startswith('UG'):
        a=ugi.setdefault(i,[0,0]);a[0]+=s;a[1]+=t
out['ug_by_inst']=ugi
# within-state vs share (latest, all 8)
w=[out['latest'][i]['within'] for i in INST];sh=[out['latest'][i]['share'] for i in INST]
rho=stats.spearmanr(w,sh);out['within_rho']=dict(rho=rho.statistic,p=rho.pvalue)
pr=stats.pearsonr(w,sh);out['within_r']=dict(r=pr.statistic,p=pr.pvalue)
# econ column reliability: max-min range per inst
out['econ']={i:dict(min=min(a['econ'] for a in out['series'][i])*100,max=max(a['econ'] for a in out['series'][i])*100,zeros=sum(1 for a in out['series'][i] if a['econ']==0)) for i in INST}
# Kolkata gap in people, aishe benchmarks
out['bench']=dict(ini=46.3,alluniv=49.8,ug_india=62.9,ref=49.5)
json.dump(out,open('cat/cat_analysis.json','w'),indent=1,default=float)
print(json.dumps({k:out[k] for k in ['latest','pooled','hetero','hetero_all','vs_ref','trend','panel_slope','prog','pg_by_inst','ug_by_inst','within_rho','within_r','econ']},indent=1,default=float))
print([ (j['i'],j['frm'],j['to'],round(j['d'],1),j['dt']) for j in big])
