import csv, re, glob, os, json, sys
txtdir, rawcsv, out = sys.argv[1], sys.argv[2], sys.argv[3]
# ---- intake parse (UG 5-yr sanctioned intake)
intake={}  # inst -> {start_year: value}
files=sorted(glob.glob(os.path.join(txtdir,'*.txt')), key=lambda p:p)
def inst_of(n): return 'bhopal' if 'bhopal' in n else n.split('_')[0]
recs=[]
for p in files:
    n=os.path.basename(p)[:-4]; i=inst_of(n)
    if i=='iisc': continue
    L=open(p,errors='replace').read().splitlines()
    k=next((j for j,l in enumerate(L) if 'Sanctioned (Approved) Intake' in l),None)
    if k is None: continue
    yrs=None
    for l in L[k:k+6]:
        f=re.findall(r'20\d\d-\d\d',l)
        if len(f)>=3: yrs=f; break
    if not yrs: continue
    fy=int(re.search(r'_(\d{4})$',n).group(1))
    for l in L[k:k+10]:
        m=re.match(r'^\s*UG\s*\[5\s*Years?\s*Program\(s\)\]\s*(.*)$',l)
        if m:
            toks=m.group(1).split()
            for y,t in zip(yrs,toks):
                if re.fullmatch(r'\d+',t): recs.append((i,int(y[:4]),int(t),fy))
            break
for i,y,v,fy in sorted(recs,key=lambda r:r[3]):   # later files overwrite earlier
    intake.setdefault(i,{})[y]=v
# ---- enrolment
rows=list(csv.DictReader(open(rawcsv)))
for r in rows:
    for k in ['nirf_year','male','female','total','within_state','outside_state','outside_country','econ_backward','soc_challenged_sc_st_obc']: r[k]=int(r[k])
    r['y']=int(r['data_year'][:4]); r['fp']=100*r['female']/r['total']; r['ins']=100*r['within_state']/r['total']; r['soc']=100*r['soc_challenged_sc_st_obc']/r['total']
ug=[r for r in rows if r['programme']=='UG 5-yr' and r['institute']!='iisc']
INST=['kolkata','pune','mohali','tvm','tirupati','berhampur','bhopal']
S={}
for i in INST:
    s=sorted([r for r in ug if r['institute']==i],key=lambda r:r['y'])
    xs=[r['y'] for r in s]; ys=[r['fp'] for r in s]
    if len(s)>=3:
        mx=sum(xs)/len(xs); my=sum(ys)/len(ys); slope=sum((a-mx)*(b-my) for a,b in zip(xs,ys))/sum((a-mx)**2 for a in xs)
    else: slope=None
    a,b=s[0],s[-1]
    S[i]=dict(first_year=a['data_year'],last_year=b['data_year'],first_f=a['fp'],last_f=b['fp'],change=b['fp']-a['fp'],slope=slope,
      dM=b['male']-a['male'],dF=b['female']-a['female'],last_M=b['male'],last_F=b['female'],last_T=b['total'],
      last_ins=b['ins'],first_ins=a['ins'],last_soc=b['soc'],first_soc=a['soc'],n=len(s))
    S[i]['growth_f_share']=100*S[i]['dF']/(S[i]['dF']+S[i]['dM']) if (S[i]['dF']+S[i]['dM'])>0 else None
# PG aggregated at latest year of UG
PG={}
for i in INST:
    ly=S[i]['last_year']; pr=[r for r in rows if r['institute']==i and r['data_year']==ly and r['programme'].startswith('PG')]
    if pr:
        f=sum(r['female'] for r in pr); t=sum(r['total'] for r in pr); PG[i]=dict(year=ly,f=f,t=t,p=100*f/t)
# intake growth
IG={}
for i,d in intake.items():
    ys=sorted(d); IG[i]=dict(first=(ys[0],d[ys[0]]),last=(ys[-1],d[ys[-1]]))
print('INTAKE',{i:{y:v for y,v in sorted(d.items())} for i,d in intake.items()})
for i in INST:
    s=S[i]; print(f"{i:10s} {s['first_year']}->{s['last_year']} F {s['first_f']:.1f}->{s['last_f']:.1f} d{s['change']:+.1f} slope {s['slope'] if s['slope'] is None else round(s['slope'],2)} dM {s['dM']:+d} dF {s['dF']:+d} growthF% {s['growth_f_share'] if s['growth_f_share'] is None else round(s['growth_f_share'],1)} instate {s['first_ins']:.0f}->{s['last_ins']:.0f} soc {s['first_soc']:.0f}->{s['last_soc']:.0f}")
print('PG',{i:(v['year'],v['f'],v['t'],round(v['p'],1)) for i,v in PG.items()})
# soc time series ranges
for i in INST:
    v=[round(r['soc']) for r in sorted([r for r in ug if r['institute']==i],key=lambda r:r['y'])]; print(i,'soc%',v)
import math
lat={i:S[i] for i in INST}
x=[lat[i]['last_ins'] for i in INST]; y=[lat[i]['last_f'] for i in INST]
mx=sum(x)/len(x); my=sum(y)/len(y); r_ins=sum((a-mx)*(b-my) for a,b in zip(x,y))/math.sqrt(sum((a-mx)**2 for a in x)*sum((b-my)**2 for b in y))
def comb(year,insts):
    m=[r for r in ug if r['data_year']==year and r['institute'] in insts]; return 100*sum(r['female'] for r in m)/sum(r['total'] for r in m), len(m)
EXTRA=dict(r_instate=r_ins, comb_2324=comb('2023-24',['kolkata','pune','mohali','tvm','tirupati','berhampur']), kpm_1718=comb('2017-18',['kolkata','pune','mohali']), kpm_2324=comb('2023-24',['kolkata','pune','mohali']))
print(EXTRA)
json.dump(dict(EXTRA=EXTRA,S=S,PG=PG,intake={i:{str(y):v for y,v in d.items()} for i,d in intake.items()}),open(out,'w'),indent=1)
