import re, sys, csv, os, glob
txtdir, out = sys.argv[1], sys.argv[2]
rows, problems = [], []
ROW = re.compile(r'^\s*(UG|PG)\s*\[(\d+)\s*Years?\b')
for path in sorted(glob.glob(os.path.join(txtdir, '*.txt'))):
    name = os.path.basename(path)[:-4]
    inst = 'bhopal' if 'bhopal' in name else name.split('_')[0]
    fy = re.search(r'_(\d{4})$', name)
    fy = int(fy.group(1)) if fy else 2026
    lines = open(path, encoding='utf-8', errors='replace').read().splitlines()
    text = '\n'.join(lines)
    m = re.search(r"NIRF'(\d{4})'", text)
    hdr_year = int(m.group(1)) if m else None
    if hdr_year and hdr_year != fy:
        problems.append(f'{name}: filename year {fy} != header NIRF year {hdr_year}')
    # data year = first academic year in the intake table
    iy = None
    for i, l in enumerate(lines):
        if 'Sanctioned (Approved) Intake' in l:
            for l2 in lines[i:i+6]:
                mm = re.search(r'(20\d\d-\d\d)', l2)
                if mm: iy = mm.group(1); break
            break
    start = next((i for i, l in enumerate(lines) if 'Total Actual Student Strength' in l), None)
    if start is None:
        problems.append(f'{name}: no student table'); continue
    end = next((i for i in range(start+1, len(lines)) if 'Placement' in lines[i]), len(lines))
    found = 0
    for l in lines[start:end]:
        r = ROW.match(l)
        if not r: continue
        rest = l[r.end():]
        nums = [int(x) for x in re.findall(r'(?<![\w.\-])\d+(?![\w.\-])', rest)]
        if len(nums) < 8:
            problems.append(f'{name}: short row {l.strip()[:80]}'); continue
        male, fem, tot, within, outside, country, econ, social = nums[:8]
        rows.append(dict(institute=inst, nirf_year=fy, data_year=iy, programme=f'{r.group(1)} {r.group(2)}-yr',
            male=male, female=fem, total=tot, within_state=within, outside_state=outside, outside_country=country,
            econ_backward=econ, soc_challenged_sc_st_obc=social, source_file=name))
        found += 1
        if male + fem != tot: problems.append(f'{name} {r.group(1)}{r.group(2)}: male+female {male+fem} != total {tot}')
        if within + outside + country != tot: problems.append(f'{name} {r.group(1)}{r.group(2)}: state split {within+outside+country} != total {tot}')
    if found == 0: problems.append(f'{name}: 0 rows parsed')
with open(out, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print(len(rows), 'rows'); print('\n'.join(problems) or 'no problems')
