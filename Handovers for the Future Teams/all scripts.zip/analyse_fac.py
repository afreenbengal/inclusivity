import csv, json, sys, collections as C
facsv, stucsv, out = sys.argv[1:4]
R = list(csv.DictReader(open(facsv)))
for r in R: r['y'] = int(r['nirf_year']); r['jy'] = int(r['join_year'])
ST = [r for r in csv.DictReader(open(stucsv)) if r['programme'] == 'UG 5-yr']
I7 = ['kolkata', 'pune', 'mohali', 'tvm', 'tirupati', 'berhampur', 'bhopal']
ALL = I7 + ['iisc']
cur = lambda r: r['working'] == 'Yes'
reg = lambda r: cur(r) and r['assoc'] == 'Regular'
F = lambda L: sum(r['gender'] == 'Female' for r in L)
pct = lambda a, n: round(100 * a / n, 1) if n else None
RANK = lambda d: {'Assistant Professor': 'Assistant', 'Associate Professor': 'Associate', 'Professor': 'Professor+', 'Dean/Director': 'Professor+'}.get(d)
A = {'series': {}, 'latest': {}, 'rank': {}, 'cohort': {}, 'growth': {}, 'gap': {}, 'nonreg': {}}
COH = {'to 2012': (0, 2012), '2013-17': (2013, 2017), '2018-21': (2018, 2021), '2022 on': (2022, 2100)}
for i in ALL:
    ys = sorted(set(r['y'] for r in R if r['institute'] == i))
    ser = []
    for y in ys:
        X = [r for r in R if r['institute'] == i and r['y'] == y]
        g = [r for r in X if reg(r)]; a = [r for r in X if cur(r)]
        ser.append(dict(y=y, n_reg=len(g), f_reg=F(g), p_reg=pct(F(g), len(g)), n_all=len(a), f_all=F(a), p_all=pct(F(a), len(a))))
    A['series'][i] = ser
    ly = ys[-1]; g = [r for r in R if r['institute'] == i and r['y'] == ly and reg(r)]
    A['latest'][i] = dict(y=ly, n=len(g), f=F(g), m=len(g) - F(g), p=pct(F(g), len(g)))
    A['rank'][i] = {k: [F([r for r in g if RANK(r['designation']) == k]), len([r for r in g if RANK(r['designation']) == k])] for k in ['Assistant', 'Associate', 'Professor+']}
    A['cohort'][i] = {k: [F([r for r in g if a <= r['jy'] <= b]), len([r for r in g if a <= r['jy'] <= b])] for k, (a, b) in COH.items()}
    nr = [r for r in R if r['institute'] == i and r['y'] == ly and cur(r) and r['assoc'] != 'Regular']
    A['nonreg'][i] = [F(nr), len(nr)]
    f0, f1 = ser[0], ser[-1]
    A['growth'][i] = dict(y0=f0['y'], y1=f1['y'], dF=f1['f_reg'] - f0['f_reg'], dM=(f1['n_reg'] - f1['f_reg']) - (f0['n_reg'] - f0['f_reg']), n0=f0['n_reg'], n1=f1['n_reg'], p0=f0['p_reg'], p1=f1['p_reg'])
    # students same NIRF year
    s = [r for r in ST if r['institute'] == i and int(r['nirf_year']) == ly]
    if s: A['gap'][i] = dict(stu=pct(int(s[0]['female']), int(s[0]['total'])), fac=A['latest'][i]['p'], stu_y=s[0]['data_year'])
    elif i != 'iisc':
        s = sorted([r for r in ST if r['institute'] == i], key=lambda r: int(r['nirf_year']))
        if s: A['gap'][i] = dict(stu=pct(int(s[-1]['female']), int(s[-1]['total'])), fac=A['latest'][i]['p'], stu_y=s[-1]['data_year'], note='latest student year, not same year')
for k in ['rank', 'cohort']:
    A[k]['pooled7'] = {c: [sum(A[k][i][c][0] for i in I7), sum(A[k][i][c][1] for i in I7)] for c in A[k]['kolkata']}
    A[k]['pooled_ex_kol'] = {c: [sum(A[k][i][c][0] for i in I7 if i != 'kolkata'), sum(A[k][i][c][1] for i in I7 if i != 'kolkata')] for c in A[k]['kolkata']}
tot7 = [sum(A['latest'][i]['f'] for i in I7), sum(A['latest'][i]['n'] for i in I7)]
exk = [tot7[0] - A['latest']['kolkata']['f'], tot7[1] - A['latest']['kolkata']['n']]
A['pooled7'] = dict(f=tot7[0], n=tot7[1], p=pct(*tot7)); A['pooled_ex_kol'] = dict(f=exk[0], n=exk[1], p=pct(*exk))
# correlation faculty vs student share (n=7)
import statistics as S
xs = [A['gap'][i]['stu'] for i in I7]; ys = [A['gap'][i]['fac'] for i in I7]
mx, my = S.mean(xs), S.mean(ys)
A['r_stu_fac'] = round(sum((a - mx) * (b - my) for a, b in zip(xs, ys)) / (sum((a - mx) ** 2 for a in xs) * sum((b - my) ** 2 for b in ys)) ** .5, 2)
# Kolkata: women needed to reach pooled-ex-Kolkata share at constant size
nk = A['latest']['kolkata']['n']; need = round(exk[0] / exk[1] * nk) - A['latest']['kolkata']['f']
A['kol_need'] = need
json.dump(A, open(out, 'w'), indent=1)
print(json.dumps({k: A[k] for k in ['pooled7', 'pooled_ex_kol', 'r_stu_fac', 'kol_need']}))
for i in ALL: print(i, A['latest'][i], 'rank', A['rank'][i], 'coh', A['cohort'][i], 'nonreg', A['nonreg'][i], 'growth', A['growth'][i], A['gap'].get(i))
print('pooled rank', A['rank']['pooled7'], 'coh', A['cohort']['pooled7'], 'exkol coh', A['cohort']['pooled_ex_kol'])
