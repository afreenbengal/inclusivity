"""Parse the NIRF 'Faculty Details' tables (pdftotext -layout output) into one CSV.
usage: python3 -I parse_faculty.py <txt_dir> <out.csv>
Personal names are deliberately NOT written to the output."""
import re, sys, os, csv, glob
txt_dir, out = sys.argv[1], sys.argv[2]
SR = re.compile(r'^\s*(\d{1,3})\s{2,}\S')
SKIP = re.compile(r'http|NIRF\)|All Report|^\s*\d+/\d+\s*$|\s\d{1,2}/15\s*$|Srno|Experience|Currently|institution\?|Months\)')
rows, probs = [], []
for fp in sorted(glob.glob(os.path.join(txt_dir, '*.txt'))):
    base = os.path.basename(fp)[:-4]
    inst = 'bhopal' if 'bhopal' in base else base.split('_')[0]
    yr = base.split('_')[-1]
    lines = open(fp, encoding='utf-8', errors='replace').read().split('\n')
    try: start = next(i for i, l in enumerate(lines) if 'Faculty Details' in l)
    except StopIteration:
        probs.append((base, 'no faculty section')); continue
    recs, cur = [], None
    for l in lines[start + 1:]:
        m = SR.match(l)
        if m and (cur is None or int(m.group(1)) == cur[0] + 1):
            cur = [int(m.group(1)), l]; recs.append(cur); continue
        if cur is not None and l.strip() and not SKIP.search(l):
            if re.match(r'^[A-Z][A-Za-z ]+$', l.strip()) and len(l.strip().split()) > 6: break
            cur[1] += ' ' + l.strip()
    n0 = len(rows)
    for sr, t in recs:
        t = re.sub(r'\s+', ' ', t)
        g = re.findall(r'\b(Male|Female)\b', t)
        if len(g) == 0 or len(set(g[-2:])) != 1 and len(g) > 1: probs.append((base, f'row {sr}: gender tokens {g}')); continue
        g = [g[-1]]
        if not re.search(r'Ph\.?D|M\.?Tech|M\.?Sc|Post|Master|Bachelor|Other|M\.?E', t): pass
        if 'Associate Dean' in t or re.search(r'Dean|Director|Vice', t): d = 'Dean/Director'
        elif 'Assistant' in t: d = 'Assistant Professor'
        elif 'Associate' in t: d = 'Associate Professor'
        elif 'Professor' in t: d = 'Professor'
        else: d = 'Other'
        yb = t.rsplit(g[0], 1)[1]
        yn = re.findall(r'\b(19\d\d|20\d\d)\b', yb)
        yn = [int(y) for y in yn]
        cw = re.findall(r'\b(Yes|No)\b', yb)
        assoc = re.findall(r'\b(Regular|Adhoc|Contractual|Visiting|Ad-hoc|Contract|Other)\b', yb)
        # leaving: second year if a leaving date exists
        join = yn[0] if yn else None
        leave = yn[1] if len(yn) > 1 else None
        rows.append(dict(institute=inst, nirf_year=yr, srno=sr, gender=g[0], designation=d,
                         working=(cw[-1] if cw else ''), join_year=join, leave_year=leave,
                         assoc=(assoc[-1] if assoc else '')))
    print(base, 'records', len(recs), 'kept', len(rows) - n0)
w = csv.DictWriter(open(out, 'w', newline=''), fieldnames=list(rows[0].keys()))
w.writeheader(); w.writerows(rows)
print(len(rows), 'rows;', len(probs), 'problems'); [print(' ', p) for p in probs[:30]]
