import openpyxl,json,sys,re,glob
UP='/root/.claude/uploads/44a78fa0-c94f-5679-9be2-3948cfb3fbf7/'
FILES={'2019-20':'a0760bb2-AISHE_Final_Report_2019-20.xlsx','2021-22':'6ad5fbbf-AISHE_Final_Report_2021-22.xlsx','2022-23':'c94d8a6c-AISHE_Final_Report_2022-23.xlsx','2023-24':'004fba08-AISHE_Final_Report_2023-24.xlsx'}
def num(c):
    if c is None: return None
    if isinstance(c,(int,float)): return float(c)
    s=str(c).strip()
    if s in('','-','--','NA'): return 0.0
    try: return float(s.replace(',',''))
    except: return 'x'
def rows(ws,start=1):
    for r in ws.iter_rows(min_row=start,values_only=True):
        yield r
def startcol(ws):
    for r in ws.iter_rows(min_row=1,max_row=8,values_only=True):
        for k,c in enumerate(r):
            if isinstance(c,str) and c.strip().lower()=='male': return k
    raise Exception('no header')
def parse_row(r,n,sc):
    lab=None
    for c in r[:sc]:
        if isinstance(c,str) and c.strip() and num(c)=='x': lab=c.strip().replace('\n',' ');break
    if lab is None: return None,None
    vals=[]
    for c in r[sc:sc+n]:
        v=num(c)
        vals.append(0.0 if v in(None,'x') else v)
    while len(vals)<n: vals.append(0.0)
    if sum(vals)==0: return None,None
    return lab,vals
def table(ws,n,first_block=False):
    sc=startcol(ws);out={};seen=False
    for r in rows(ws):
        lab,vals=parse_row(r,n,sc)
        if lab is None or seen: continue
        if lab.startswith('Grand Total'):
            out['__total']=vals
            if first_block: seen=True
            continue
        out[lab]=vals
    return out
D={}
for yr,f in FILES.items():
    wb=openpyxl.load_workbook(UP+f,data_only=True)
    sh={n:wb[n] for n in wb.sheetnames}
    key=lambda p:[n for n in sh if n.startswith(p)][0]
    t21=table(sh[key('21Teacher')],21)
    t30=table(sh[key('30Type')],21,True)
    t27=table(sh[key('27')],21,True)
    t14=table(sh[key('14')],12)
    t11=table(sh[key('11Programme')],12)
    phd=[v for k,v in t11.items() if k.startswith('Ph.D.-Doctor of Ph')]
    D[yr]=dict(t21=t21,t30=t30,t27=t27,t14=t14,phd=phd[0] if phd else None)
    print(yr,len(t21),len(t30),len(t27),len(t14),'phd',phd[:1])
json.dump(D,open('ais/ais.json','w'))
