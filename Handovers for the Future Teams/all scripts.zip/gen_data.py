import json, pandas as pd
SP='/tmp/claude-0/-home-claude/44a78fa0-c94f-5679-9be2-3948cfb3fbf7/scratchpad'
INST=['berhampur','bhopal','kolkata','mohali','pune','tvm','tirupati']
NAME=dict(berhampur='Berhampur',bhopal='Bhopal',kolkata='Kolkata',mohali='Mohali',pune='Pune',tvm='Thiruvananthapuram',tirupati='Tirupati')
d=pd.read_csv(SP+'/data_raw.csv'); u=d[d.programme=='UG 5-yr'].copy()
fac=json.load(open(SP+'/fac/fac_analysis.json')); cat=json.load(open(SP+'/cat/cat_analysis.json'))
# latest women students
lat={}
for i in INST:
    r=u[u.institute==i].sort_values('nirf_year').iloc[-1]; lat[i]=dict(f=int(r.female),t=int(r.total),y=r.data_year,p=100*r.female/r.total)
pf=sum(v['f'] for v in lat.values()); pt=sum(v['t'] for v in lat.values())
glance=[]
for i in INST:
    s=lat[i]; f=fac['latest'][i]; c=cat['latest'][i]
    glance.append([NAME[i], f"{s['p']:.1f}% ({s['y']})", f"{f['p']:.1f}% ({f['f']} of {f['n']}; {f['y']})", f"{c['share']*100:.1f}% ({c['data']})"])
tp=fac['pooled7']; cp=cat['pooled']
pool=['All seven pooled', f"{100*pf/pt:.1f}% ({pf:,} of {pt:,})", f"{tp['p']:.1f}% ({tp['f']} of {tp['n']})", f"{cp['share']*100:.1f}% ({cp['s']:,} of {cp['t']:,})"]
# appendix tables
nirf=[2019,2020,2021,2022,2023,2024,2025,2026]
def fmt(x): return '–' if x is None else x
A1=[];A2=[];A3=[]
for i in INST:
    row=[NAME[i]]
    for y in nirf:
        q=u[(u.institute==i)&(u.nirf_year==y)]
        row.append('–' if q.empty else f"{100*q.iloc[0].female/q.iloc[0].total:.1f}")
    A1.append(row)
    row=[NAME[i]];sm={r['y']:r for r in fac['series'][i]}
    for y in nirf: row.append('–' if y not in sm else f"{sm[y]['p_reg']:.1f} ({sm[y]['n_reg']})")
    A2.append(row)
    row=[NAME[i]];sm={r['nirf']:r for r in cat['series'][i]}
    for y in nirf: row.append('–' if y not in sm else f"{sm[y]['share']*100:.1f}")
    A3.append(row)
json.dump(dict(glance=glance,pool=pool,A1=A1,A2=A2,A3=A3,years=nirf),open(SP+'/gen/gen_data.json','w'),indent=1)
for r in glance+[pool]: print(r)
print(A1[2],A2[2],A3[2])

# ================= extended tables =================
import numpy as np
O=json.load(open(SP+'/gen/gen_analysis.json'))
N=O['nat']
# glance: add IISc reference row and range row
iu=O['iisc_ug'];fi=fac['latest']['iisc'];ci=cat['latest']['iisc']
iisc_row=['IISc Bangalore (reference)', f"{iu['p']:.1f}% (4-year UG, {iu['y']})", f"{fi['p']:.1f}% ({fi['f']} of {fi['n']}; {fi['y']})", f"{ci['share']*100:.1f}% ({ci['data']})"]
rg=O['ranges']
range_row=['Range across the seven (points)', f"{rg['stu'][1]-rg['stu'][0]:.1f}", f"{rg['fac'][1]-rg['fac'][0]:.1f}", f"{rg['cat'][1]-rg['cat'][0]:.1f}"]
# Table 2 benchmarks
pgw=O['pg_women']; pg_f=sum(v['f'] for v in pgw.values()); pg_t=sum(v['t'] for v in pgw.values())
pgp=[v['p'] for v in pgw.values()]
five=['kolkata','pune','tvm','tirupati','bhopal']
ug_by=cat['ug_by_inst'];pg_by=cat['pg_by_inst']
ugc=100*sum(ug_by[i][0] for i in five)/sum(ug_by[i][1] for i in five); pgc=100*sum(pg_by[i][0] for i in five)/sum(pg_by[i][1] for i in five)
q=d[(d.institute=='iisc')&(d.nirf_year==2026)];a=q[q.programme=='UG 4-yr'];b=q[q.programme.str.startswith('PG')]
iug=100*a.soc_challenged_sc_st_obc.sum()/a.total.sum();ipg=100*b.soc_challenged_sc_st_obc.sum()/b.total.sum()
w=N['women_fac'];cs_=N['cat_students'];cf=N['cat_fac']
cr=lambda lo,hi:f"{lo:.1f}–{hi:.1f}"
ug_vals=[100*lat[i]['f']/lat[i]['t'] for i in INST]
T2=[
 ['Women, UG students', f"{100*pf/pt:.1f}% (range {cr(min(ug_vals),max(ug_vals))})", f"{iu['p']:.1f}%", f"{N['women_ug']['ini']:.1f}%", f"{N['women_ug']['alluniv']:.1f}%", f"{N['women_ug']['india']:.1f}%"],
 ['Women, PG students', f"{100*pg_f/pg_t:.1f}% (range {cr(min(pgp),max(pgp))}; five IISERs)", f"{O['iisc_pg']['p']:.1f}%", f"{N['women_pg']['ini']:.1f}%", '–', f"{N['women_pg']['india']:.1f}%"],
 ['Women, faculty', f"{tp['p']:.1f}% (range {cr(rg['fac'][0],rg['fac'][1])})", f"{fi['p']:.1f}%", f"{w['ini']:.1f}%", f"{w['alluniv']:.1f}%", f"{w['india']:.1f}%"],
 ['SC, ST and OBC, UG students', f"{ugc:.1f}% (five IISERs)", f"{iug:.1f}%", '–', '–', '62.9%'],
 ['SC, ST and OBC, PG students', f"{pgc:.1f}% (five IISERs)", f"{ipg:.1f}%", '–', '–', '57.4%'],
 ['SC, ST and OBC, all UG and PG students', f"{cp['share']*100:.1f}% (range {cr(rg['cat'][0],rg['cat'][1])})", f"{ci['share']*100:.1f}%", f"{cs_['ini']:.1f}%", f"{cs_['alluniv']:.1f}%", '–'],
 ['SC, ST and OBC, faculty', '16.0% (Kolkata only)', '–', f"{cf['ini']:.1f}%", f"{cf['alluniv']:.1f}%", f"{cf['india']:.1f}%"],
]
# Table 3 people scale
need=O['need_ini']
T3=[]
for i in ['berhampur','bhopal','kolkata','mohali','pune','tvm','tirupati','iisc']:
    v=need[i]; T3.append([NAME.get(i,'IISc Bangalore (reference)') if i!='iisc' else 'IISc Bangalore (reference)', f"{v['f']} of {v['n']} ({v['p']:.1f}%)", str(v['target']) , ('0' if v['more']==0 else f"+{v['more']}"), f"{100/v['n']:.1f}"])
# A4 home-state by year
A4=[]
for i in INST:
    row=[NAME[i]]
    for y in nirf:
        q_=u[(u.institute==i)&(u.nirf_year==y)]
        row.append('–' if q_.empty else f"{100*q_.iloc[0].within_state/q_.iloc[0].total:.0f}")
    A4.append(row)
# A5 rank
rk=O['rank'];A5=[]
for i in ['berhampur','bhopal','kolkata','mohali','pune','tvm','tirupati','iisc']:
    row=[NAME[i] if i!='iisc' else 'IISc (reference)']
    for r_ in ['Assistant','Associate','Professor+']:
        fm,tt=rk[i][r_]; row.append(f"{fm} of {tt} ({100*fm/tt:.0f}%)" if tt else '–')
    A5.append(row)
J=json.load(open(SP+'/gen/gen_data.json'))
J.update(dict(iisc_row=iisc_row,range_row=range_row,T2=T2,T3=T3,A4=A4,A5=A5))
json.dump(J,open(SP+'/gen/gen_data.json','w'),indent=1)
for r in T2+T3+A5: print(r)
