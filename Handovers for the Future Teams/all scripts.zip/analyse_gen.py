import json, itertools, numpy as np, pandas as pd
from scipy import stats
SP = '/tmp/claude-0/-home-claude/44a78fa0-c94f-5679-9be2-3948cfb3fbf7/scratchpad'
INST7 = ['berhampur', 'bhopal', 'kolkata', 'mohali', 'pune', 'tvm', 'tirupati']
INST8 = INST7 + ['iisc']
HOST = dict(berhampur='Odisha', bhopal='Madhya Pradesh', kolkata='West Bengal', mohali='Punjab', pune='Maharashtra',
            tvm='Kerala', tirupati='Andhra Pradesh', iisc='Karnataka')
d = pd.read_csv(SP + '/data_raw.csv')
fac = json.load(open(SP + '/fac/fac_analysis.json')); cat = json.load(open(SP + '/cat/cat_analysis.json'))
ais = json.load(open(SP + '/ais/ais_analysis.json'))
out = {}

def perm_p(x, y, method='pearson'):
    x = np.array(x, float); y = np.array(y, float)
    res = stats.pearsonr(x, y) if method == 'pearson' else stats.spearmanr(x, y)
    return float(res[0]), float(res[1])

def fisher_ci(r, n):
    z = np.arctanh(r); se = 1 / np.sqrt(n - 3); return np.tanh(z - 1.96 * se), np.tanh(z + 1.96 * se)

# ---- home-state, UG five-year (women) ----
u = d[d.programme == 'UG 5-yr'].copy()
u['fp'] = 100 * u.female / u.total; u['hp'] = 100 * u.within_state / u.total
lat = u.sort_values('nirf_year').groupby('institute').tail(1).set_index('institute')
hs = {i: float(lat.loc[i, 'hp']) for i in INST7}; wp = {i: float(lat.loc[i, 'fp']) for i in INST7}
r, p = perm_p([hs[i] for i in INST7], [wp[i] for i in INST7], 'pearson')
rho, prho = perm_p([hs[i] for i in INST7], [wp[i] for i in INST7], 'spearman')
lo, hi = fisher_ci(r, 7)
out['home_women'] = dict(r=r, p=p, lo=lo, hi=hi, rho=rho, prho=prho, n=7, hs=hs, wp=wp)
# IISc UG 4-yr latest for reference
q = d[(d.institute == 'iisc') & (d.programme == 'UG 4-yr')].sort_values('nirf_year').iloc[-1]
out['iisc_ug'] = dict(f=int(q.female), t=int(q.total), p=100 * q.female / q.total, hs=100 * q.within_state / q.total, y=q.data_year)
pg = d[(d.institute == 'iisc') & (d.programme.str.startswith('PG')) & (d.nirf_year == 2026)]
out['iisc_pg'] = dict(f=int(pg.female.sum()), t=int(pg.total.sum()), p=100 * pg.female.sum() / pg.total.sum())

# ---- home-state, all UG+PG (category) ----
L = cat['latest']
hsc = {i: 100 * L[i]['within'] for i in INST8}; cs = {i: 100 * L[i]['share'] for i in INST8}
rc, pc = perm_p([hsc[i] for i in INST8], [cs[i] for i in INST8], 'pearson')
rhoc, prhoc = perm_p([hsc[i] for i in INST8], [cs[i] for i in INST8], 'spearman')
lo, hi = fisher_ci(rc, 8)
out['home_cat'] = dict(r=rc, p=pc, lo=lo, hi=hi, rho=rhoc, prho=prhoc, n=8, hs=hsc, cs=cs)
# excluding Berhampur (probable reporting change)
k = [i for i in INST8 if i != 'berhampur']
rho2, p2 = perm_p([hsc[i] for i in k], [cs[i] for i in k], 'spearman')
out['home_cat_ex_berh'] = dict(rho=rho2, p=p2, n=len(k))

# ---- home-state over time (UG 5-yr) and within-institute association ----
ts = {i: u[u.institute == i].sort_values('nirf_year')[['nirf_year', 'hp', 'fp']].values.tolist() for i in INST7}
out['home_ts'] = ts
dem_h = []; dem_f = []
for i in INST7:
    a = np.array(ts[i])
    if len(a) >= 3:
        dem_h += list(a[:, 1] - a[:, 1].mean()); dem_f += list(a[:, 2] - a[:, 2].mean())
rw, pw = stats.pearsonr(dem_h, dem_f)
out['within_inst'] = dict(r=rw, p=pw, n=len(dem_h), institutes=[i for i in INST7 if len(ts[i]) >= 3])
# per-institute change first->last
out['home_change'] = {i: dict(h0=ts[i][0][1], h1=ts[i][-1][1], f0=ts[i][0][2], f1=ts[i][-1][2], n=len(ts[i])) for i in INST7}
# home-state within-institute for category (all programmes) over time
cts = {i: [(s['nirf'], 100 * s['within'], 100 * s['share']) for s in cat['series'][i]] for i in INST8}
out['cat_ts'] = cts
dh = []; dc = []
for i in INST8:
    a = np.array(cts[i])
    if len(a) >= 3:
        dh += list(a[:, 1] - a[:, 1].mean()); dc += list(a[:, 2] - a[:, 2].mean())
rw2, pw2 = stats.pearsonr(dh, dc); out['within_inst_cat'] = dict(r=rw2, p=pw2, n=len(dh))

# ---- host-state context ----
S = ais['states']
def share(st, g): return 100 * (S[st]['s' + g]) / S[st]['sall']
host = {}
for i in INST8:
    st = HOST[i]; s = S[st]
    comb = 100 * (s['ssc'] + s['sst'] + s['sobc']) / s['sall']
    fw = 100 * s['fF'] / s['fall']
    fcomb = 100 * (s['fsc'] + s['fst'] + s['fobc']) / s['fall']
    host[i] = dict(state=st, comb=comb, fw=fw, fcomb=fcomb)
out['host'] = host
flat = {i: 100 * fac['latest'][i]['p'] / 100 if False else fac['latest'][i]['p'] for i in INST8}
xs = [host[i]['comb'] for i in INST8]; ys = [cs[i] for i in INST8]
out['host_cat'] = dict(zip(['rho', 'p'], perm_p(xs, ys, 'spearman')), n=8)
out['host_cat']['r'], out['host_cat']['pr'] = perm_p(xs, ys, 'pearson')
xs2 = [host[i]['fw'] for i in INST8]; ys2 = [flat[i] for i in INST8]
out['host_fw'] = dict(zip(['rho', 'p'], perm_p(xs2, ys2, 'spearman')), n=8)
out['host_fw']['r'], out['host_fw']['pr'] = perm_p(xs2, ys2, 'pearson')
out['fac_latest_p'] = flat

# ---- national benchmarks ----
tt = ais['typ']['2023-24']; tot = tt['__total']; ini = tt['Institute of National Importance']; cen = tt['Central University']
def comb_f(t): return 100 * (t['fsc'] + t['fst'] + t['fobc']) / t['fall']
def comb_s(t): return 100 * (t['ssc'] + t['sst'] + t['sobc']) / t['sall']
out['nat'] = dict(
    women_ug=dict(india=49.5, alluniv=41.3, ini=26.5), women_pg=dict(india=55.7, ini=30.9), women_phd=dict(india=50.1, alluniv=48.6, ini=34.6),
    women_fac=dict(india=100 * ais['nat']['2023-24']['allF'] / ais['nat']['2023-24']['all'], ini=100 * ini['fF'] / ini['fall'], alluniv=100 * tot['fF'] / tot['fall'], central=100 * cen['fF'] / cen['fall']),
    cat_students=dict(india_ug=62.9, india_pg=57.4, ini=comb_s(ini), alluniv=comb_s(tot), central=comb_s(cen)),
    cat_fac=dict(india=45.06, ini=comb_f(ini), alluniv=comb_f(tot), central=comb_f(cen)))

# ---- people-scale: women faculty needed to reach INI average at present size ----
ini_w = out['nat']['women_fac']['ini'] / 100
need = {}
for i in INST8:
    f = fac['latest'][i]; n, fw_ = f['n'], f['f']
    target = int(np.ceil(ini_w * n - 1e-9)); need[i] = dict(n=n, f=fw_, target=target, more=max(0, target - fw_), p=f['p'])
out['need_ini'] = need

# ---- Wilson intervals for institute faculty women share vs INI ----
def proportion_confint(k, n, method='wilson'):
    z = 1.959964; ph = k / n; den = 1 + z * z / n
    c = (ph + z * z / (2 * n)) / den; h = z * np.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
    return c - h, c + h
wil = {}
for i in INST8:
    f = fac['latest'][i]; lo_, hi_ = proportion_confint(f['f'], f['n'], method='wilson'); wil[i] = (100 * lo_, 100 * hi_)
out['fac_wilson'] = wil
sw = {}
for i in INST7:
    r_ = lat.loc[i]; lo_, hi_ = proportion_confint(int(r_.female), int(r_.total), method='wilson'); sw[i] = (100 * lo_, 100 * hi_)
out['stu_wilson'] = sw

# ---- net growth ----
A = json.load(open(SP + '/analysis.json'))['S']
out['growth_stu'] = {i: dict(start=A[i]['first_f'], growth=A[i]['growth_f_share'], dF=A[i]['dF'], dM=A[i]['dM']) for i in INST7}
G = fac['growth']
out['growth_fac'] = {i: dict(start=G[i]['p0'], growth=100 * G[i]['dF'] / (G[i]['dF'] + G[i]['dM']) if (G[i]['dF'] + G[i]['dM']) else None, dF=G[i]['dF'], dM=G[i]['dM'], y0=G[i]['y0'], y1=G[i]['y1']) for i in INST7}
out['rank'] = {i: fac['rank'][i] for i in INST8}
out['pg_women'] = json.load(open(SP + '/analysis.json'))['PG']

# range summary
w_stu = [wp[i] for i in INST7]; w_fac = [flat[i] for i in INST7]; c_stu = [cs[i] for i in INST7]
out['ranges'] = dict(stu=(min(w_stu), max(w_stu)), fac=(min(w_fac), max(w_fac)), cat=(min(c_stu), max(c_stu)))
json.dump(out, open(SP + '/gen/gen_analysis.json', 'w'), indent=1, default=float)

# ---- print key numbers ----
f2 = lambda x: f'{x:.2f}'
print('home~women  r', f2(out['home_women']['r']), 'p', f2(out['home_women']['p']), 'CI', f2(out['home_women']['lo']), f2(out['home_women']['hi']), 'rho', f2(rho), 'p', f2(prho))
print('home~cat    r', f2(rc), 'p', f2(pc), 'CI', f2(out['home_cat']['lo']), f2(out['home_cat']['hi']), 'rho', f2(rhoc), 'p', f2(prhoc), '| ex-Berh rho', f2(rho2), 'p', f2(p2))
print('within inst women/home  r', f2(rw), 'p', f2(pw), 'n', len(dem_h), '| cat/home r', f2(rw2), 'p', f2(pw2), 'n', len(dh))
print('home shares women study', {i: round(v, 1) for i, v in hs.items()})
print('home shares cat study', {i: round(v, 1) for i, v in hsc.items()})
print('host', {i: (h['state'], round(h['comb'], 1), round(h['fw'], 1)) for i, h in host.items()})
print('host~cat', out['host_cat'], '\nhost~fw', out['host_fw'])
print('nat', json.dumps(out['nat'], default=float))
print('need', {i: (v['f'], v['n'], v['target'], v['more']) for i, v in need.items()})
print('iisc', out['iisc_ug'], out['iisc_pg'])
print('ranges', out['ranges'])
print('growth_stu', {i: (round(v['start'], 1), v['growth'] if v['growth'] is None else round(v['growth'], 0)) for i, v in out['growth_stu'].items()})
print('growth_fac', {i: (v['start'], v['growth'] and round(v['growth'])) for i, v in out['growth_fac'].items()})
print('home change', {i: (round(v['h0']), round(v['h1']), v['n']) for i, v in out['home_change'].items()})
