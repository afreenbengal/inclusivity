import json,numpy as np
from scipy import stats
D=json.load(open('ais/ais.json'));YRS=['2019-20','2021-22','2022-23','2023-24']
def aiv(t):
    return t[[k for k in t if 'ndia' in k][0]]
OUT={'years':YRS}
# national
nat={}
for y in YRS:
    A=aiv(D[y]['t21'])
    nat[y]=dict(all=A[2],allF=A[1],sc=A[5],scF=A[4],st=A[8],stF=A[7],obc=A[11],obcF=A[10])
OUT['nat']=nat
a,b=nat['2019-20'],nat['2023-24']
OUT['netadd']={k:dict(d=b[k]-a[k],share=(b[k]-a[k])/(b['all']-a['all']),growth=b[k]/a[k]-1) for k in ('all','sc','st','obc')}
# types
TY=['Institute of National Importance','Central University','State Public University','State Private University','Deemed University-Private','Deemed University-Government']
typ={}
for y in YRS:
    typ[y]={}
    for t in TY+['__total']:
        f=D[y]['t30'].get(t);s=D[y]['t27'].get(t)
        if f is None or s is None: continue
        typ[y][t]=dict(fall=f[2],fsc=f[5],fst=f[8],fobc=f[11],fF=f[1],fscF=f[4],fstF=f[7],fobcF=f[10],
                       sall=s[2],ssc=s[5],sst=s[8],sobc=s[11])
OUT['typ']=typ
# states 2023-24
y='2023-24';t21=D[y]['t21'];t14=D[y]['t14'];ai=[k for k in t21 if 'ndia' in k][0];ai14=[k for k in t14 if 'ndia' in k][0]
st={}
def norm(n): return n.replace('&','and').lower().replace(' ','')
m14={norm(k):k for k in t14}
for k,v in t21.items():
    if k==ai: continue
    k14=m14.get(norm(k))
    if k14 is None:
        print('no match',k);continue
    s=t14[k14]
    st[k]=dict(fall=v[2],fF=v[1],fsc=v[5],fst=v[8],fobc=v[11],sall=s[2],ssc=s[5],sst=s[8],sobc=s[11])
OUT['states']=st
# regression across states, all states with >=1000 teachers
def reg(cat,minT=1000,excl=()):
    xs=[];ys=[];names=[]
    for k,v in st.items():
        if v['fall']<minT or k in excl: continue
        xs.append(100*v['s'+cat]/v['sall']);ys.append(100*v['f'+cat]/v['fall']);names.append(k)
    r=stats.linregress(xs,ys)
    # bootstrap slope
    rng=np.random.default_rng(1);sl=[]
    xs_a=np.array(xs);ys_a=np.array(ys)
    for _ in range(4000):
        i=rng.integers(0,len(xs),len(xs));
        if np.ptp(xs_a[i])==0: continue
        sl.append(stats.linregress(xs_a[i],ys_a[i]).slope)
    return dict(n=len(xs),slope=r.slope,intercept=r.intercept,r=r.rvalue,lo=float(np.percentile(sl,2.5)),hi=float(np.percentile(sl,97.5)))
OUT['reg']={c:reg(c) for c in ('sc','st','obc')}
OUT['reg_large']={c:reg(c,10000) for c in ('sc','st','obc')}
OUT['reg_noNE']={c:reg(c,1000,excl=('Arunachal Pradesh','Assam','Manipur','Meghalaya','Mizoram','Nagaland','Sikkim','Tripura')) for c in ('sc','st','obc')}
# pipeline 2023-24 PhD
ph=D['2023-24']['phd'];OUT['phd']={y:dict(all=D[y]['phd'][2],sc=D[y]['phd'][5],st=D[y]['phd'][8],obc=D[y]['phd'][11]) for y in YRS}
json.dump(OUT,open('ais/ais_analysis.json','w'),indent=1)
# print key
for y in YRS:
    n=nat[y];print(y,n['all'],'SC %.2f ST %.2f OBC %.2f comb %.2f women %.1f SCw %.1f STw %.1f OBCw %.1f'%(100*n['sc']/n['all'],100*n['st']/n['all'],100*n['obc']/n['all'],100*(n['sc']+n['st']+n['obc'])/n['all'],100*n['allF']/n['all'],100*n['scF']/n['sc'],100*n['stF']/n['st'],100*n['obcF']/n['obc']))
print(OUT['netadd'])
for y in YRS:
    for t in ('Institute of National Importance','Central University','State Public University','State Private University'):
        v=typ[y].get(t)
        if v: print(y,t[:12],v['fall'],'F: %.1f %.1f %.1f | S: %.1f %.1f %.1f'%(100*v['fsc']/v['fall'],100*v['fst']/v['fall'],100*v['fobc']/v['fall'],100*v['ssc']/v['sall'],100*v['sst']/v['sall'],100*v['sobc']/v['sall']))
for k in ('reg','reg_large','reg_noNE'): print(k,{c:{kk:round(vv,2) for kk,vv in v.items()} for c,v in OUT[k].items()})
for y in YRS: p=OUT['phd'][y];print(y,'PhD shares',round(100*p['sc']/p['all'],1),round(100*p['st']/p['all'],1),round(100*p['obc']/p['all'],1))
