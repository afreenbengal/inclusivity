import openpyxl,json,re
U='/root/.claude/uploads/44a78fa0-c94f-5679-9be2-3948cfb3fbf7/'
F={'2019-20':'a0760bb2-AISHE_Final_Report_2019-20.xlsx','2021-22':'6ad5fbbf-AISHE_Final_Report_2021-22.xlsx','2022-23':'c94d8a6c-AISHE_Final_Report_2022-23.xlsx','2023-24':'004fba08-AISHE_Final_Report_2023-24.xlsx'}
def num(x):
    if x is None: return 0.0
    if isinstance(x,(int,float)): return float(x)
    s=str(x).replace(',','').strip()
    try: return float(s)
    except: return 0.0
def sheet(wb,prefix):
    for n in wb.sheetnames:
        if n.strip().startswith(prefix): return wb[n]
    raise KeyError(prefix)
O={}
for y,f in F.items():
    wb=openpyxl.load_workbook(U+f,read_only=True,data_only=True); D={}
    def firstnum(r):
        for i,x in enumerate(r):
            if isinstance(x,(int,float)) or (isinstance(x,str) and re.fullmatch(r'[\d,\.]+',x.strip())): return i
        return None
    def isnumlike(x): return isinstance(x,(int,float)) or (isinstance(x,str) and re.fullmatch(r'[\d,\.]+',x.strip()) is not None)
    def tbl_states(ws,n):
        out={};india=None
        for r in ws.iter_rows(values_only=True):
            lab=' '.join(str(x) for x in r[:2] if isinstance(x,str))
            if 'All India' in lab:
                rr=r[[i for i,x in enumerate(r) if isinstance(x,str) and 'All India' in x][0]+1:]; rr=[x for x in rr if x is not None]; india=[num(x) for x in rr[:n]]
            elif isinstance(r[1],str) and isnumlike(r[0]) is not None and not isinstance(r[0],str) or (isinstance(r[0],str) and r[0].strip().replace('.0','').isdigit() and isinstance(r[1],str)):
                out[str(r[1]).strip()]=[num(x) for x in r[2:2+n]]
        return india,out
    ws=sheet(wb,'6TotalEnr'); D['t6_india'],D['t6_states']=tbl_states(ws,27)
    ws=sheet(wb,'22TeacherPost'); D['t22_india'],D['t22_states']=tbl_states(ws,21)
    for key,pref in [('ger','19GER'),('gpi','20GPI')]:
        ws=sheet(wb,pref); st={}
        for r in ws.iter_rows(values_only=True):
            lab=' '.join(str(x) for x in r[:2] if isinstance(x,str))
            if 'All India' in lab: D[key+'_india']=[num(x) for x in r[2:] if x is not None]
            elif isinstance(r[1],str) and isinstance(r[0],(int,float)) : st[r[1].strip()]=[num(x) for x in r[2:] if x is not None]
        D[key+'_states']=st
    ws=sheet(wb,'12UGDisc'); ug={}
    for r in ws.iter_rows(values_only=True):
        names=[x.strip() for x in r[:3] if isinstance(x,str)]
        nums=[x for x in r[2:7] if isinstance(x,(int,float))]
        if names and len(nums)>=3 and not names[-1].startswith('Table') and names[-1] not in ('Discipline',) : ug[names[-1]]=nums[:3] if len(nums)==3 else nums[-3:]
        if names and len(nums)>=3 and len(names)>=2 and names[0] in ('Engineering & Technology','Medical Science'): ug[names[0]+' (first sub)']=nums[:3]
    D['ug']=ug
    ws=sheet(wb,'13PGDisc'); pg={}
    for r in ws.iter_rows(values_only=True):
        names=[x.strip() for x in r[:3] if isinstance(x,str)]
        tot=[x for x in names if x.endswith(' Total')]
        if tot:
            off=3 if isinstance(r[0],(int,float)) else 2
            pg[tot[0][:-6].strip()]=[num(x) for x in r[off:off+9]]
    D['pg']=pg
    ws=sheet(wb,'29Type'); ty={}; part='a'
    for r in ws.iter_rows(values_only=True):
        if any(isinstance(x,str) and 'Table 29' in x for x in r[:4]):
            tt=' '.join(x for x in r[:4] if isinstance(x,str)); part='b' if '(b)' in tt else 'a'
        names=[x.strip() for x in r[:2] if isinstance(x,str)]
        fi=firstnum(r[1:]) if names else None
        if names and names[-1] not in ('Type of University','Male','Female') and 'Table' not in names[-1] and 'Post-wise' not in names[-1] and 'Professor' not in names[-1]:
            ni=[i for i,x in enumerate(r[:2]) if isinstance(x,str)][-1]; idx=[i for i in range(ni+1,len(r)) if isnumlike(r[i])]
            if idx and (names[-1]!='Grand Total' or True) and not isinstance(r[0],str) or (idx and isinstance(r[0],str) and r[0]!='Type of University'):
                i0=idx[0]; ty[part+'|'+names[-1]]=[num(x) for x in r[i0:i0+21]]
    D['t29']=ty; O[y]=D
json.dump(O,open('nat.json','w'))
for y in O:
    d=O[y]; print(y,'t6',d['t6_india'][-3:],'t22',d['t22_india'][:3],len(d['t22_india']),'ger',d['ger_india'][:3],'gpi',d['gpi_india'][:3],'ug',len(d['ug']),d['ug'].get('Science'),'pg',len(d['pg']),d['pg'].get('Science'),'t29',list(d['t29'])[:3],len(d['t6_states']),len(d['t22_states']))
